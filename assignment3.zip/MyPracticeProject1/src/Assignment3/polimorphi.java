package Assignment3;

class Shape 
{
	void ares()
	{
		System.out.println("Class Shape");
	}
}
class Rectangle extends Shape
{
	void ares()
	{
		System.out.println("Area of Rectangle = length * breadth");
	}
}

class Circle extends Shape
{
	void ares()
	{
		System.out.println("Area of Circle = π * r * r");
	}
}
public class polimorphi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		Shape ref =new Rectangle();
		ref.ares();
		Shape ref1 = new Circle();
		ref1.ares();
	}

}
