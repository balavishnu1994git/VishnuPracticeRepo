package Assignment3;
//16.  Method Overriding with super
class Hospital
{
	void emergencyService()
	{
		System.out.println("Call 909 for Emergency Service");
	}
}
class CityHospital extends Hospital
{
	void emergencyService() 
	{super.emergencyService();
	System.out.println("Emergency ward opened in City hospital");
		
	}
}

public class methodoverride_super {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CityHospital obj = new CityHospital();
		obj.emergencyService();

	}

}
