package Assignment3;
//13. Inheritance (Multilevel)
class Device{
	void start()
	{
		System.out.println("Device turned on");
	}
	
	
}
class Mobile extends Device
{
	void calling()
	{
		System.out.println("We can Make a call!");
	}
	
}
class SmartPhone extends Mobile
{
	void internet()
	{
		System.out.println("Mobile started to using internet");
	}
}

public class Multilevelinher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		 SmartPhone obj = new  SmartPhone();
		 obj.start();
		 obj.calling();
		 obj.internet();
		 
		
		
	}

}
