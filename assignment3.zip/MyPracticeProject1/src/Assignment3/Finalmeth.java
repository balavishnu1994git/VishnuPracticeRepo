package Assignment3;
//09 Final

class Bank {
	final String IFSC="UBINO4545";
	final void showIFSC()
	{
		System.out.println("IFSC :"+IFSC);
	}
	
}
class HDFC extends Bank
{
	void showIFSC1()// change to  showIFSC()
	{
		System.out.println("HDFC IFSC :"+IFSC);
	}
}

public class Finalmeth {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HDFC obj= new HDFC();
		obj.showIFSC1();
		Bank obj2= new Bank();
		obj2.showIFSC();
		

	}

}
