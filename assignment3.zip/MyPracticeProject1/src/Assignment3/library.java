package Assignment3;
class Library1
{
	String libraryName ="The ART Gallery";
	Library1()
	{
		System.out.println("Welcome to the Library!"+libraryName);
	}
	void showLocation()
	{
		System.out.println("This library is located in Mumbai");
	}
}

public class library {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Library1 obj= new Library1();
		obj.showLocation();
		

	}

}
