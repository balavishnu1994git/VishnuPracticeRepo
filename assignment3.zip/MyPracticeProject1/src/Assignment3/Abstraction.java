package Assignment3;


abstract class  Animal
{
	abstract void sound();
	//void sound() {} normal method override
	
}

class Dog extends Animal
{
	public void sound()
	{
		System.out.println("Dog make sound- barks");
	}
}
	
	class Cat extends Animal
	{
		public void sound()
		{
			System.out.println("Cat make sound- meows");
		}
	}
	
public class Abstraction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cat obj= new Cat();
		obj.sound();
		Dog obj2= new Dog();
		obj2.sound();

	}

}
