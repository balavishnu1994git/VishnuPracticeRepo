package Assignment3;
class Product
{
	 int productId;
	 String productName;
	 float price;
	 
	 Product()
	 {
		 System.out.println("Product Created");
	 }
  Product(int Id,String Name,float p )
  {
	  this.productId=Id;
	  this.productName=Name;
	  this.price=p;
	  
  }
  void displayProduct() 
  {
	
	  System.out.println("productId:"+productId+" product Name: "+productName+"price : "+price);
  
  }
  
}
public class const_overloading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Product obj =new Product();
		Product obj1=new Product(1042,"Hand wash",125f);
		obj.displayProduct();
		obj1.displayProduct();
	}

}
