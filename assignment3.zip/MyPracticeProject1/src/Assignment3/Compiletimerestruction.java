package Assignment3;
//22. Final Keyword + Constant
class GovernmentRules
{
	final int MAX_WORKING_HOURS = 8;
	void displayRules() {
        System.out.println("Maximum Working Hours: " + MAX_WORKING_HOURS);
    //    int MAX_WORKING_HOURS=12;
    //    System.out.println("Maximum Working Hours: " + MAX_WORKING_HOURS);
    }
	
	
}
public class Compiletimerestruction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		GovernmentRules obj = new GovernmentRules();
		obj.displayRules();
		//obj.MAX_WORKING_HOURS=12;
	}

}
