package Assignment3;
//21.  Static Concepts
class University
{
	static String  country = "India";
	String universityName;
	void display( String universityName)
	{
		this.universityName =universityName;
		System.out.println("University Name: " + universityName);
        System.out.println("Country: " + country);
        System.out.println();
	}

}

public class Ststiccon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		University obj = new University();
		obj.display("MGU");
		obj.display("KERALA");
		
		University obj1 = new University();
		obj1.display("KTU");
		obj1.display("DELHI");
		
				}

}
