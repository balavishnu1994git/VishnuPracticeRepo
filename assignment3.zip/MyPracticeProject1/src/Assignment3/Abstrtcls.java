package Assignment3;
//17.  Abstract Class + Real Usage
abstract class Employee12
{
	abstract void calculateSalary(int day);
	
	void employeeDetails(int id, String name)
	{
		System.out.println("Employee Id:"+id+"  Name : "+name);
	
}
}
class FullTimeEmployee extends Employee12
{
	void calculateSalary(int day)
	{
		float slry = day * 750;
		System.out.println("Daily salary 750");
		System.out.println("Salary for "+day+" days , Fulltime employee is "+slry);
		System.out.println();
		
	}
}

class PartTimeEmployee extends Employee12
{
	void calculateSalary(int day)
	{
		float slry = day * 600;
		System.out.println("Daily salary 600");
		System.out.println("Salary for "+day+" days , part time employee is "+slry);
	
		
		
	}
}
public class Abstrtcls {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee12 ref= new FullTimeEmployee();
		ref.employeeDetails(1245,"Vishnu");
		ref.calculateSalary(30);
		
		PartTimeEmployee obj = new PartTimeEmployee();
		obj.employeeDetails(4510, "Manu");
		obj.calculateSalary(30);
		
		
		
		
		

	}

}
