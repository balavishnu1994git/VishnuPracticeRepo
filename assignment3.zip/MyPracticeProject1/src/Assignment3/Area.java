package Assignment3;
//24
class Shape1
{
	int length ;
	void square()
	{
		
		System.out.println("Area of Square "+ length* length);
	}
	void rectanglesquare(int breadth)
	{
	
		System.out.println("Area of Rectangle "+ length* breadth);
	}
	void circle( )
	{
		System.out.println("Area of Circle "+ 3.14*length*length);
	}
}
public class Area {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape1 obj= new Shape1();
		obj.length=10;
		obj.square();
		
		obj.length=5;
		obj.rectanglesquare(2);
		
		obj.length=5;
		obj.circle();
		
	}

}




