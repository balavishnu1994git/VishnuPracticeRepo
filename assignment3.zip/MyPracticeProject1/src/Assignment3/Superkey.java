package Assignment3;
class Person
{
	   Person()
	{
		System.out.println("Person Created");
	}
}

class Student extends Person

{ 
	Student()
	{
		super();
		System.out.println("Student Created");
		
	}
	
	
}

public class Superkey {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student obj =new Student();
	
		

	}

}

