package Assignment3; 
//15.  Method Overloading (Bank Scenario)
class LoanCalculator 
{
	void calculateLoan(int amount)
	{
		System.out.println("The Loan Amount:"+amount);
		
	}
	void calculateLoan(int amount, double interestRate)
	{
		System.out.println("The interest rate is:"+interestRate+ "%" );
		
		double d = interestRate;
		int i = (int) d;
		float t =amount * i /100;
	    float b=t+amount;
	    System.out.println("Intrest amount is : "+t);
		System.out.println("Total amount : "+ b);
		
	}
}

public class Methodoverld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LoanCalculator obj= new LoanCalculator();
		obj.calculateLoan(100);
		obj.calculateLoan(100, 15.99);

	}

}
