package Assignment3;
class Employee
{
	private int empId;
	private String empName;
	private int salary;
	
	
public int getEmpId() {
		return empId;
	}
public String getEmpName() {
		return empName;
	}
public int getSalary() {
		return salary;
	}

public void setEmpId(int empId) {
	this.empId = empId;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public void setSalary(int salary) {
	this.salary = salary;
}
 void displayDetails()
{
	System.out.println("Employee Id  :"+empId);
	System.out.println("Employee Name:"+empName);
	System.out.println("Employee salary:"+getSalary());
	
}
}
public class Encapsulation_getset {

	public static void main(String[] args) {
		
		Employee obj=new Employee();
		
		obj.setSalary(100);
		obj.setEmpName("vishnu");
		obj.setEmpId(1245);
		obj.displayDetails();
		

	}

}
