package Assignment3;

class  Student1{
	static String collegeName="NSSC";
	String name;
	int Rollno;
	
	void display(int Rollno,String name )
	
	{
		this.name=name;
		this.Rollno=Rollno;
		
		System.out.println(" Roll Number :"+Rollno+" Name :"+name+" Collage name : "+collegeName );
		
	}

static void change()
{
	 Student1.collegeName="New NSSC";
	
}
}
public class Staticlas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student1 obj= new Student1();
		obj.display(12, "Hari");
		obj.change();
		obj.display(13, "vishnu");
obj.display(7485, "Manu");
		
	}

}
