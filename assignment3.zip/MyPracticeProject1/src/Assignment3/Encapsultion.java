package Assignment3;
//12.  Encapsulation + Validation Logic

class Account
{
	private String accountHolderName;
	private int balance;
	
	public String getAccountHolderName() {
		return accountHolderName;
	}
	
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	
	public int getBalance() {
		return balance;
	}
	
	public void setBalance(int balance) {
		if (balance <=0)
{
	System.out.println(" Balance cannot be negative");
}
else	this.balance = balance;
	}
	
	
}
public class Encapsultion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Account obj= new Account();
		obj.setBalance(-100);
		obj.setBalance(100);
		obj.setAccountHolderName("Vishnu");
		System.out.println("Account Holder Name: "+obj.getAccountHolderName());
		System.out.println("Balance            : "+obj.getBalance());
		
		
		

	}

}
