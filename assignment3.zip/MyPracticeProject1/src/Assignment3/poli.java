package Assignment3;
//19. Polymorphism (Runtime + Upcasting)
class Camera
{
	void capture()
	{
		System.out.println("Capturing Image");
	}
}
class DSLCamera extends Camera
{
	void capture()
	{
		System.out.println("Capturing Image using DSLR");
	}
}

public class poli {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Camera ref = new DSLCamera();
		ref.capture();

	}

}
