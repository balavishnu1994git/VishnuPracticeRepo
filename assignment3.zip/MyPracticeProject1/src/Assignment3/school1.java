package Assignment3;
class school
{
	String name;
	
	school(String name)
	
	{this.name=name;
		System.out.println(" The "+name+" SCHOOL");
		System.out.println("-------------------------------");
	}
	void display()
	{
		System.out.println(" This School is based out of Kolkata");
		
	}
}

public class school1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		school obj = new school("MOUNT INTERNATIONAL");
		obj.display();
	}

}
