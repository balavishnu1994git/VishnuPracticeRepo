package Assignment3;
class School02
{
	String name;
	String address;
	String strength;
	
	School02(String name,String strength)
	{
		System.out.println("Name is :"+name);
		System.out.println("Name is :"+strength);
		System.out.println("--------------------");
	}
	School02(String name,String address,String strength)
	{
		this.name=name;
		this.address=address;
		this.strength=strength;
	}
	
	void display()
	{
		System.out.println("Name is :"+name);
		System.out.println("Strength is :"+strength);
		System.out.println("Address is : "+address);
	}
}

public class Schoolconstruct {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		School02 obj= new School02("vishnu","12");
		School02 obj2= new School02("vishnu","12","test adress");
		obj2.display();
		
	}

}
