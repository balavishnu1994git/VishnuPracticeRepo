package Assignment3;
//14. Hierarchical Inheritance

class Course 
{
	void courseInfo()
	{
		System.out.println("The course  structure " );
	}
	
}
class Science extends Course 
{
	void sc()
	{
		//super.courseInfo();
		System.out.println("  Science course -> Physics, Chemistry, Biology ,etc..");
		System.out.println();
	}
}

class commerce extends Course 
{
	void co()
	{
		//super.courseInfo();
		System.out.println("  Commerce course ->  Accounting, Economics, ");
		System.out.println();
	}
}
class Arts  extends Course 
{
	void Ar()
	{
		super.courseInfo();
		System.out.println("  Arts course ->  History, Political Science, Sociology");
		System.out.println();
	}
}

public class Hirarchi_inhe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Science obj3 = new Science();
		  obj3.courseInfo();
		  obj3.sc();
		  
		Arts obj =new Arts();
		
		//obj.courseInfo();
		obj.Ar();
  
		commerce obj2= new commerce();
		obj2.courseInfo();
		obj2.co();
		  
		  
		 
		  
  
  

	}

}
