package Assignment3;

class Vehicle
{
	void fuelType()
	{
		System.out.println("Runs on Fuel");
	}
}
class ElectricCar extends 	Vehicle
{
	void fuelType()
	{
		System.out.println("Runs on Electricity");
	}
}


public class Inheritan_override {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehicle obj1= new Vehicle();
		obj1.fuelType();
		
		ElectricCar obj= new ElectricCar();
		obj.fuelType();

	}

}
