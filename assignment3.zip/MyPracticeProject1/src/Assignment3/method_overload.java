package Assignment3;

class Calculator
{
	void add()
	{int a=10;
	int b=5;
	System.out.println("A+b="+ (a+b));
		
	}
	int add(int a, int b)
	{
		return a+b;
	}
	double add(double a, double b)
	{
		return a+b;
	}

}
public class method_overload {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Calculator obj= new Calculator();
		obj.add();
	System.out.println("Addition of integers,A+B="+obj.add(10,10));	
	System.out.println("Addition of doubles,A+B="+obj.add(10.5,25));
	}

}
