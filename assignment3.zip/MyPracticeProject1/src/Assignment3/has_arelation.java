package Assignment3;
//Aggregation (Has-A Relationship)
class Engine
{
	void engineInfo()
	{
		System.out.println("Engin information");
	}
}

class Car
{
	Engine obj= new Engine();
}
public class has_arelation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Car obj1= new Car();
	}

}
