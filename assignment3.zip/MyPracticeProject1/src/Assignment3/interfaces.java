package Assignment3;

interface Payment
{
	void makePayment();
}

class UPI implements Payment
{
	public void  makePayment() {
		System.out.println("Paying throw UPI");
		
	}
}
class CreditCard implements Payment
{
	public void  makePayment() {
		System.out.println("Paying throw Credit Card");
	}
}


public class interfaces {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Payment r= new UPI();
		r.makePayment();
		Payment r1= new  CreditCard();
		r1.makePayment();
		
	}

}
