package Assignment3;
//18.  Interface with Multiple Implementations
interface Transport
{
	void booking();
	
}
class Bus implements Transport
{
	public void booking()
	{
		System.out.println("Your Bus ticket boocking is confirmed");
		System.out.println();
	}
}
class Flight implements Transport
{
	public void booking()
	{
		System.out.println("Your flight ticket  boocking is confirmed");
	}
}
public class interfsc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Bus obj = new Bus();
		obj.booking();
		Flight obj2 = new Flight();
		obj2.booking();
		
		
		//Transport ref = new Bus();
		//ref.booking();
		
	}

}
